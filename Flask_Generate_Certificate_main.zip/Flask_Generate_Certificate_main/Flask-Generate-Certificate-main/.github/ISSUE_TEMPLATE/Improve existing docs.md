---
name: Documentation Change
about: Help us in improve Documentation 
title: ''
labels: 'Documentation'
assignees: ''

---


### What part(s) of the article would you like to see updated?

<!-- Give as much detail as you can to help us understand the change you want to see. Why should the docs be changed? What use cases does it support? What is the expected outcome? -->

### Which Program are you part of?
<!--
Example how to mark a checkbox:-
- [x] Part of this program.
-->
- [] GSSOC21
- [] Any other

### Additional information

<!-- Add any other context or screenshots about the feature request here. -->
