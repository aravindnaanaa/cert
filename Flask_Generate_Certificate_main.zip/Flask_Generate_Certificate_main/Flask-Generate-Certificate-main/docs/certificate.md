| File Name                     | Certificate Mockup |   Width and Height used |
| :---                          |       ----         |         -----:          |    
| Design_1                      |  [Mockup_1 Link](https://drive.google.com/drive/folders/1FEQUV5YTw2fZbl0DNuZ9EZfm62d2rTrX)| *width=1080* *height=768*
| Design_2                      |  [Mockup_2 Link](https://drive.google.com/drive/folders/1cyxrxk3OxRaiGxeFR50eVibHi-dSyth7)| *width=1080* *height=768*
